
User Manual
===========

.. toctree::

   overview.rst
   installing.rst
   jit.rst
   generated-jit.rst
   vectorize.rst
   jitclass.rst
   cfunc.rst
   pycc.rst
   parallel.rst
   stencil.rst
   troubleshoot.rst
   faq.rst
   examples.rst
