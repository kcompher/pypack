
Device management
=================

TODO...
