from __future__ import print_function
import os
import coverage

coverage.process_startup()
print(os.environ['COVERAGE_PROCESS_START'])


