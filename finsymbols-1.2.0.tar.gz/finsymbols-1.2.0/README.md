finsymbols
==========

[![Build Status](https://travis-ci.org/skillachie/finsymbols.svg?branch=master)](https://travis-ci.org/skillachie/finsymbols)

Obtains stock symbols and relating information for SP500, AMEX, NYSE, and NASDAQ 

 * S&P 500 listings are obtained dynamically by parsing Wikipedia
 * AMEX,NYSE and NASDAQ are obtained by gathering NASDAQ data

How to use  http://skillachie.github.io/finsymbols/
