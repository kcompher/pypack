.. datashape documentation master file, created by
   sphinx-quickstart on Fri Sep  4 08:31:10 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to datashape's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   overview
   types
   pattern_matching
   grammar
   releases



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

