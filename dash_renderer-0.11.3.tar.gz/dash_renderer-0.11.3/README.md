### Dash Renderer - The Dash Frontend

This Dash Renderer is a modular front-end for [Dash](https://plot.ly/products/dash). To learn more about Dash, [view the user guide](https://plot.ly/dash).

[![CircleCI](https://circleci.com/gh/plotly/dash-renderer.svg?style=svg)](https://circleci.com/gh/plotly/dash-renderer)

