TODO: need to reorganize benchmarking
