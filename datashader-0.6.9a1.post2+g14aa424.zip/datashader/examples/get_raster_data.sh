mkdir -p data
cd data
wget http://s3.amazonaws.com/bokeh_data/geotiff_example.zip
unzip geotiff_example.zip
rm geotiff_example.zip
cd ..

