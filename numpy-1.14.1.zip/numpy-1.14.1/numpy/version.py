
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.14.1'
version = '1.14.1'
full_version = '1.14.1'
git_revision = '7dcee7a469ad1bbfef1cd8980dc18bf5869c5391'
release = True

if not release:
    version = full_version
