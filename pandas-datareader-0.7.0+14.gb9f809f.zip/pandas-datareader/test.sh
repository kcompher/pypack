#!/bin/bash

pytest -s -r xX pandas_datareader "$@"
