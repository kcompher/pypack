Engima
------

.. py:module:: pandas_datareader.enigma

.. autoclass:: EnigmaReader
   :members:
   :inherited-members:
