AlphaVantage
------------

.. py:module:: pandas_datareader.av.forex

.. autoclass:: AVForexReader
   :members:
   :inherited-members:


.. py:module:: pandas_datareader.av.time_series

.. autoclass:: AVTimeSeriesReader
	:members:
	:inherited-members:


.. py:module:: pandas_datareader.av.sector

.. autoclass:: AVSectorPerformanceReader
	:members:
	:inherited-members:


.. py:module:: pandas_datareader.av.quotes

.. autoclass:: AVQuotesReader
	:members:
	:inherited-members: