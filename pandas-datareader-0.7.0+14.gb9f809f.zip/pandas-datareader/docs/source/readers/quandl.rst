Quandl
------

.. py:module:: pandas_datareader.quandl

.. autoclass:: QuandlReader
   :members:
   :inherited-members:
