Morningstar
-----------

.. py:module:: pandas_datareader.mstar.daily

.. autoclass:: MorningstarDailyReader
   :members:
   :inherited-members:
