Eurostat
--------

.. py:module:: pandas_datareader.eurostat

.. autoclass:: EurostatReader
   :members:
   :inherited-members:
