Robinhood
---------

.. py:module:: pandas_datareader.robinhood

.. autoclass:: RobinhoodHistoricalReader
   :members:
   :inherited-members:

.. autoclass:: RobinhoodQuoteReader
   :members:
   :inherited-members:
